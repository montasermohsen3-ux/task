import { Outlet } from "react-router-dom"
import Header from './components/Header'
import Footer from './components/Footer'
import About from "./components/About";
<Route path="/about" element={<About />} />
const App = () => {
  return (
    <>
      <Header />
      <Outlet />
      <Footer />
    </>
  )
}

export default App